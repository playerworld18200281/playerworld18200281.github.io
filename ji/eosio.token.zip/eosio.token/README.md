eosio.token
-----------

This eosio contract allows users to create, issue, and manage tokens on
eosio based blockchains.


